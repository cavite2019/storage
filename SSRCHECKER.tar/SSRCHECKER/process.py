from django.conf import settings
from .models import *
import os, paramiko, yaml, json, time, base64


class SSRsetup():
    def __init__(self):
        self.ansiblefile = os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/ansible.cfg')
        self.hostsfile = os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/hosts')
        self.ansible_conf = {
            'inventory' : os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/hosts'),
            'library' : os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/my_modules'),
            'local_tmp' : os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/tmp'),
            'roles_path' : os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/roles'),
            'log_path': os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/logs'),
            'host_key_checking' : False,
            'deprecation_warnings' : False,
            'command_warnings' : False
        }

    def ansibleConf(self):
        open(self.ansiblefile, 'w').close()
        open(self.ansiblefile, 'a').write('[defaults]\n')
        for key, value in self.ansible_conf.items():
            open(self.ansiblefile, 'a').write('{} = {}\n'.format(key, value))


    def ansibleHosts(self):
        open(self.hostsfile, 'w').close()
        ssr_hosts = ['[ssr_init]\n', '[ssr_config]\n']
        for ssr_host in ssr_hosts:
            open(self.hostsfile, 'a').write(ssr_host)
            for data in SSRinitModel.objects.all():
                open(self.hostsfile, 'a').write('{} ansible_ssh_port={} ansible_ssh_user={} ansible_ssh_pass={}\n'.format(data.IP, data.PORT, data.USER, data.PASSWORD))
        open(self.hostsfile, 'a').write('[multi:children]\nssr_init\nssr_config\n[multi:vars]\nAUTH_BASIC_ENABLED=False\nHOST_KEY_CHECKING=False\nANSIBLE_HOST_KEY_CHECKING=False\n')

    def ansibleExecute(self):
        ansiblehosts = os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/hosts')
        ansible_main = os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/main.yml')
        limit = 'ssr_init,ssr_config'
        tags = 'initialization_ssr,config_ssr'
        os.system("ansible-playbook -i {} {} --ssh-common-args='-o StrictHostKeyChecking=no' --limit {} --tags {} > {} &".format(ansiblehosts, ansible_main, limit, tags, os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/logs/logs')))


    def ansiblerecap(self):
        logs = open(os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/logs/logs'), 'r').read()
        # logs = open(os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/logs/testlogs'), 'r').read()
        if "PLAY RECAP" in logs.strip('\n'):
            return True

class SSRsave():
    def ssrinfo(self, IPok, SSRerror='TIMEOUT', SSRport=28032, SSRuser='ommgr'):
        try:
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            ssh.connect('{}'.format(IPok), username=SSRuser, port=SSRport, timeout=30)
            stdin, stdout, stderr = ssh.exec_command('cat /etc/shadowsocksr/user-config.json')
            ssrdata = stdout.read().decode('utf-8')
            ssrdata = json.loads(ssrdata)
            ssrpassfile = os.path.join(settings.BASE_DIR,
                                       'SSRCHECKER/aom/ansible/roles/p.ssr_init/vars/main.yml')
            ssrload = open(ssrpassfile)
            ssrpassword = yaml.load(ssrload, yaml.SafeLoader)['ssr_password']
            stdin, stdout, stderr = ssh.exec_command("su -c 'ss -l'")
            time.sleep(3)
            stdin.write('{}\n'.format(ssrpassword))
            stdin.flush()
            ssrport = stdout.read().decode('utf-8')
            if any(str(ssrdata["server_port"]) in s for s in ssrport.split('\n')):
                ssrstatus = 'OK'
            else:
                ssrstatus = 'ERROR'
            ip = IPok
            # ip = requests.get('http://ipinfo.io/ip').text
            password64 = base64.b64encode(ssrdata["password"].encode("utf-8")).decode("utf-8")
            SS_url = '{}:{}@{}:{}'.format(ssrdata["method"], ssrdata["password"], str(ip), ssrdata["server_port"])
            SSR_url = '{}:{}:{}:{}:{}:{}'.format(str(ip), ssrdata["server_port"],
                                                 ssrdata["protocol"].replace('_compatible', ''), ssrdata["method"],
                                                 ssrdata["obfs"],
                                                 str(password64).replace('=', '').replace('+', '-').replace('/', '_'))
            SS_url64 = base64.b64encode(str(SS_url).encode("utf-8")).decode("utf-8")
            SSR_url64 = base64.b64encode(str(SSR_url).encode("utf-8")).decode("utf-8")
            ssh.close()
            return {'ssr_link': 'ssr://{}'.format(SSR_url64.replace('+', '-').replace('/', '_').replace('=', '')),
                    'ssr_code': 'http://doub.pw/qr/qr.php?text=ssr://{}'.format(
                        SSR_url64.replace('+', '-').replace('/', '_').replace('=', '')),
                    'ss_link': 'ss://{}'.format(SS_url64.replace('+', '-').replace('/', '_').replace('=', '')),
                    'ss_code': 'http://doub.pw/qr/qr.php?text=ss://{}'.format(
                        SS_url64.replace('+', '-').replace('/', '_').replace('=', '')),
                    'ssr_status': ssrstatus,
                    'ssr_port': ssrdata["server_port"],
                    }

        except:
            return SSRerror



    def ssrlogs(self, username):
        logs = open(os.path.join(settings.BASE_DIR, 'SSRCHECKER/aom/ansible/logs/logs'), 'r').read()
        IPS = {}
        final = []
        ipinfo = {}

        for ip in SSRinitModel.objects.all():
            IPS[ip.IP] = ip.IDC

        for i, value in IPS.items():
            for i2 in logs.split('PLAY RECAP')[-1].split('\n'):
                if i in i2:
                    final.append(i2)

        for i in final:
            ipinfo[i.split(':')[0].strip()] = i.split(':')[-1].strip().split()

        if "PLAY RECAP" in logs:
            for key, value in ipinfo.items():
                if "unreachable=1" in value:
                    # ssrinfo = self.ssrinfo(key)
                    try:
                        data = SSRinithistoryModel.objects.get(IP=key)
                        data.STATUS='UNREACHABLE'
                        data.LOGS=logs
                        data.IDC=IPS[key]
                        data.USERNAME=username
                        data.CREATED=datetime.datetime.now()
                        data.save()
                    except:
                        SSRinithistoryModel.objects.create(
                            IP=key,
                            STATUS='UNREACHABLE',
                            LOGS=logs,
                            IDC=IPS[key],
                            USERNAME=username,
                            CREATED=datetime.datetime.now()
                            )
                    SSRinitModel.objects.all().delete()
                elif int(value[-1].split('=')[-1]) > 0:
                    #ssrinfo = self.ssrinfo(key,SSRerror='FAILED')
                    try:
                        data = SSRinithistoryModel.objects.get(IP=key)
                        data.STATUS='FAILED'
                        data.LOGS=logs
                        data.IDC=IPS[key]
                        data.USERNAME=username
                        data.CREATED=datetime.datetime.now()
                        data.save()
                    except:
                        SSRinithistoryModel.objects.create(
                            IP=key,
                            STATUS='FAILED',
                            LOGS=logs,
                            IDC=IPS[key],
                            USERNAME=username,
                            CREATED=datetime.datetime.now()
                            )
                    SSRinitModel.objects.all().delete()
                else:
                    ssrinfo = self.ssrinfo(key)
                    try:
                        data = SSRinithistoryModel.objects.get(IP=key)
                        data.STATUS='COMPLETED'
                        data.LOGS=logs
                        data.IDC=IPS[key]
                        data.USERNAME=username
                        data.CREATED=datetime.datetime.now()
                        data.save()
                    except:
                        SSRinithistoryModel.objects.create(
                            IP=key,
                            STATUS='COMPLETED',
                            LOGS=logs,
                            IDC=IPS[key],
                            USERNAME=username,
                            CREATED=datetime.datetime.now()
                            )
                    try:
                        data = SSRinitdataModel.objects.get(IP=key)
                        data.IP=key
                        data.PORT=ssrinfo['ssr_port']
                        data.STATUS=ssrinfo['ssr_status']
                        data.SSR_LINK=ssrinfo['ssr_link']
                        data.SSR_CODE=ssrinfo['ssr_code']
                        data.IDC=IPS[key]
                        data.SS_CODE=ssrinfo['ssr_code']
                        data.SS_LINK=ssrinfo['ssr_link']
                        data.LAST_CHECK=datetime.datetime.now()

                    except:
                        SSRinitdataModel.objects.create(
                            IP=key,
                            PORT=ssrinfo['ssr_port'],
                            STATUS=ssrinfo['ssr_status'],
                            SSR_LINK=ssrinfo['ssr_link'],
                            SSR_CODE=ssrinfo['ssr_code'],
                            IDC=IPS[key],
                            SS_CODE=ssrinfo['ssr_code'],
                            SS_LINK=ssrinfo['ssr_link'],
                            LAST_CHECK=datetime.datetime.now()
                            )

                    SSRinitModel.objects.all().delete()

